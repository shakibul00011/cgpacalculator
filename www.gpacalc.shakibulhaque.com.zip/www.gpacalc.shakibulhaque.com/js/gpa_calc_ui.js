
var gpa_calc_ui = (function ($) {

   return {
      init: function (calc) {

         var setError = function (type) {
            $("#calc-err .message").html(type.desc);
            $("#calc-err").show();
         };

         $("#container").on("click", "button.close", function (event) {
            $(this).parent("div.alert-error").hide();
         });

         var setRepeats = function (on) {
            $("td[name='repeatCell']").toggle(on);
            $("th[name='repeatCell']").toggle(on);
            $("#repeatButton").html((on) ? "Hide Repeats" : "Show Repeats");
            calc.set_repeat(on);
         };

         var setCumulative = function (on) {
            $('#curGPAButton').html((on ? "Hide" : "Show") + " Cumulative GPA");
            $('#curGPABox').toggle(on);
            calc.set_cumulative(on);
         };

        
         var toggleRepeats = function () {
            if ($("td[name='repeatCell']:hidden").length > 1) {
               if (!$('#curGPABox').is(':visible')) {
                  setCumulative(true);
               }

               setRepeats(true);
            }
            else {
               setRepeats(false);
            }
         };


         setRepeats(false);

      
         $('#repeatButton').click(toggleRepeats);

      
         var toggleCumulative = function () {
            if ($('#curGPABox:hidden').length > 0) {
               setCumulative(true);
            }
            else {
               setCumulative(false);
               setRepeats(false);
            }
         };

       
         $('#curGPABox').hide();
         $('#curGPAButton').click(toggleCumulative);

      
         $('#curUnits').change(function (event) {
            calc.get_cur_grades().set_units($(this).val(), setError);
         });
         $('#curGPA').change(function (event) {
            calc.get_cur_grades().set_gpa($(this).val(), setError);
         });

    
         var dispatch = function (listen) {
       
            $('#termUnits').on('change', listen, function (event) {
           
               var courses = calc.get_courses();
            
               var row = $(this).closest('tr').index();
               var course = courses[row - 1];

             
               var name = $(this).attr('name');

               if (name === 'units[]') {
           
                  course.set_units($(this).val(), setError);
               }
               else if (name === 'gradeHigh[]') {
            
                  course.set_grade_high($(this).val());
               }
               else if (name === 'gradeLow[]') {
               
                  course.set_grade_low($(this).val());
               }
               else if (name === 'gradePrev[]') {
               
                  course.set_prev_grade($(this).val());
               }
               else if (name === 'repeat[]') {
             
                  course.set_repeat($(this).is(':checked'));
               }
            });
         };


         dispatch('td input');
         dispatch('td select');

        
         $('#addRow').click(function (event) {
            calc.add_course();
            $('#newRow').clone().removeAttr('id').appendTo('#termUnits');
         });


         $('#removeRow').click(function (event) {

            if (calc.get_courses().length > 3) {
               calc.remove_last_course();
               $('#termUnits tr:last').remove();
            }
         });
      }
   };
}) (jQuery);
