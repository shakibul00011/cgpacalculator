(function ($) {
   $(window).load(function () {
      $('#container').gpaCalc();

    
      $('#container').on('click', 'div.expandPane', function (event) {
         $(this).siblings('div.expandPane').children('ul').slideUp('fast');
         $(this).children('ul').slideToggle('fast');
      });

 
      $('body').on('click', 'a.no-nav', function (event) {
         return false;
      });
   });
}) (jQuery);
